import java.util.Objects;

public class Car {
    private String brand;
    private int year;
    private double price;
    private String name;

    // Constructor
    public Car(String brand, int year, double price, String name) {
        this.brand = brand;
        this.year = year;
        this.price = price;
        this.name = name;
    }

    // Getters
    public String getBrand() {
        return brand;
    }

    public int getYear() {
        return year;
    }

    public double getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }

    // Method to compare two cars based on brand, year, price, and name
    public boolean compareTo(Car otherCar) {
        return this.brand.equals(otherCar.getBrand()) &&
               this.year == otherCar.getYear() &&
               Double.compare(this.price, otherCar.getPrice()) == 0 &&
               this.name.equals(otherCar.getName());
    }
    // Method to create a Car object
    public static Car createCar(String brand, int year, double price, String name) {
        return new Car(brand, year, price, name);
    }

    // Method to convert Car object to a string
    public String toString() {
        return "Car{" +
                "brand='" + brand + '\'' +
                ", year=" + year +
                ", price=" + price +
                ", name='" + name + '\'' +
                '}';
    }

    // Main method for testing
    public static void main(String[] args) {
        Car car1 = new Car("Toyota", 2020, 25000, "Camry");
        Car car2 = new Car("Honda", 2019, 20000, "Civic");

        System.out.println("Car 1 and Car 2 are the same: " + car1.compareTo(car2)); // Output: true

        System.out.println("Price of Car 1: " + car1.getPrice()); // Output: 25000.0
        System.out.println("Year of Car 1: " + car1.getYear()); // Output: 2020

        System.out.println("Car 1: " + car1); // Output: Car{brand='Toyota', year=2020, price=25000.0, name='Camry'}
}
}
