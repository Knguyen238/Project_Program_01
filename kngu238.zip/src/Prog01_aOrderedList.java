import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Prog01_aOrderedList {
    public static void main(String[] args) {
        Scanner userInput = new Scanner(System.in);
        aOrderedList orderedList = new aOrderedList();

        char continueProgram = 'Y';
        while (continueProgram == 'Y') {
            // Read input from file and perform operations on orderedList
            try {
                Scanner scanner = getInputFile("Enter input filename: ");
                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    String[] parts = line.split(",");
                    if (parts[0].equals("A")) {
                        String make = parts[1].trim();
                        int year = Integer.parseInt(parts[2].trim());
                        int price = Integer.parseInt(parts[3].trim());
                        Car car = new Car(make, year, price, make);
                        orderedList.add(car);
                    } else if (parts[0].equals("D")) {
                        int index = Integer.parseInt(parts[1].trim());
                        orderedList.remove(index);
                    }
                }
                scanner.close();
            } catch (FileNotFoundException e) {
                System.err.println("File not found: " + e.getMessage());
                return;
            }

            // Output the content of the array in the specified format
            System.out.println("Number of cars: " + orderedList.size());
            for (int i = 0; i < orderedList.size(); i++) {
                System.out.println();
                Car car = (Car) orderedList.get(i);
                System.out.println(car);
            }

            // Ask the user if they want to continue
            System.out.print("Do you want to continue? (Y/N): ");
            continueProgram = userInput.nextLine().toUpperCase().charAt(0);
        }
        userInput.close();
    }

	private static Scanner getInputFile(String string) {
		// TODO Auto-generated method stub
		return null;
	}

    // getOutputFile method remains the same

    // getInputFile method remains the same
}