import java.util.Arrays;

public class aOrderedList {
    private static final int SIZE_INCREMENT = 20;
    private Comparable[] oList;
    private int listSize;
    private int numObjects;

    public aOrderedList() {
        listSize = SIZE_INCREMENT;
        numObjects = 0;
        oList = new Comparable[listSize];
    }

    public void add(Car car) {
        if (numObjects == listSize) {
            expandArray(); // Expand array if it's full
        }
        int index = findInsertionIndex(car); // Find the correct position to insert newObject
        for (int i = numObjects; i > index; i--) {
            oList[i] = oList[i - 1]; // Shift elements to make space for newObject
        }
        oList[index] = car; // Insert newObject at the correct position
        numObjects++; // Increment the number of objects
    }

    private void expandArray() {
        Comparable[] newArray = Arrays.copyOf(oList, listSize + SIZE_INCREMENT);
        listSize += SIZE_INCREMENT; // Update the listSize
        oList = newArray; // Update reference to the new array
    }

    private int findInsertionIndex(Comparable newObject) {
        int index = 0;
        while (index < numObjects && oList[index].compareTo(newObject) < 0) {
            index++;
        }
        return index;
    }

    public int size() {
        return numObjects;
    }

    public Comparable get(int index) {
        if (index < 0 || index >= numObjects) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        return oList[index];
    }

    public boolean isEmpty() {
        return numObjects == 0;
    }

    public void remove(int index) {
        if (index < 0 || index >= numObjects) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        for (int i = index; i < numObjects - 1; i++) {
            oList[i] = oList[i + 1]; // Shift elements to fill the hole
        }
        numObjects--; // Decrement the number of objects
    }
}